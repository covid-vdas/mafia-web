<script>
</script>

<section>
	<h1 class="fs-1 fw-bold text-bold mb-4">
		Welcome to VDAS
	</h1>
	<p class="fs-4 mb-5">
		COVID-19 Violation Detection Assistance System
	</p>
	<span>
		<a href="/image-detector" class="me-1">
			<button class="btn btn-primary btn-lg">
				<i class="bi bi-images" /> Detect images
			</button>
		</a>
		<a href="/video-detector" class="ms-1">
			<button class="btn btn-dark btn-lg">
				<i class="bi bi-play-btn" /> Detect video
			</button>
		</a>
	</span>
</section>

<style>
	section {
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		flex: 1;
	}

	h1 {
		width: 100%;
	}
</style>
